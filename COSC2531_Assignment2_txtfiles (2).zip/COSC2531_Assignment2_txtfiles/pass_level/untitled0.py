# -*- coding: utf-8 -*-
"""
Created on Sat May  6 18:21:26 2023

@author: sanka
"""


#customer = open("C:/Users/sanka/OneDrive/Desktop/Programming Fundamentals/Assignment 2/COSC2531_Assignment2_txtfiles/pass_level/customers.txt", "r")
#customer_content = customer.readlines()
#customer_content = customer_content.tolist()

#print(customer_content)                                                             


def read_txt_file(file_path):
    file_path = customer_file_path
    file_content = open(file_path)
    file_content_list = file_content.readlines()
    return file_content_list
    

customer_file_path = "C:/Users/sanka/OneDrive/Desktop/Programming Fundamentals/Assignment 2/COSC2531_Assignment2_txtfiles/pass_level/customers.txt" 
movies_path = "C:/Users/sanka/OneDrive/Desktop/Programming Fundamentals/Assignment 2/COSC2531_Assignment2_txtfiles/pass_level/movies.txt"     
tickets_path = "C:/Users/sanka/OneDrive/Desktop/Programming Fundamentals/Assignment 2/COSC2531_Assignment2_txtfiles/pass_level/tickets.txt"     

value_ = read_txt_file(customer_file_path)    
        
def add(a,b):
    return a + b
    
v = add(1,2)


file_path = customer_file_path
file_content = open(file_path)
#file_content_list = file_content.readlines()

def read_text_file(file_path):
    with open(file_path) as file_in:
        lines = []
        for line in file_in:
            list_line = line.split(",")
            lines.append(list_line)
    return lines   
            
        
value_function = read_text_file(movies_path)

        
a = "c11, henry"
b = a.split(",")
print(b)
 
# ['C11', Henry,]