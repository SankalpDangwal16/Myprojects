Project Name: Understanding the Factors that Shape Academic Success: A Study on the User knowledge modeling dataset
Student Name: Sankalp Dangwal
Student ID  :s4000592

## Description
This study seeks to determine what distinguishes students who are categorized as high-level, middle-level, low-level, and extremely low-level knowledge users by analyzing the behavior of various students.

## Files and Directories
- `Assignment2.ipynb`: Jupyter Notebook containing the code.
- `data/`: Directory containing the dataset files and any other related data files.
  - `Training_Data.csv`: CSV file containing the training data.
  - `Test_Data.csv`: CSV file containing the test data.
- `readme.txt`: This file, providing an overview of the project.
- `Assignment2_report.pdf` : This file discuss the approach and result of the study in detail.

## Dependencies
The project relies on the following Python libraries:
- pandas: Data manipulation and analysis library.
- numpy: Numerical computing library.
- matplotlib: Data visualization library.
- seaborn: Statistical data visualization library.
- scikit-learn: Machine learning library.

## Installation
To run the code in the Jupyter Notebook, follow these steps:
1. Install Python (version >= 3.7): https://www.python.org/downloads/
2. Install the required libraries by running the following commands one by one:
	pip install pandas
	pip install numpy
	pip install matplotlib
	pip install seaborn
	pip install scikit-learn
3. Navigate to the project directory using the command prompt or terminal.
5. Launch Jupyter Notebook by running the command:
	jupyter notebook
6. Open the `Assignment2.ipynb` file in Jupyter Notebook.
7. Modify the paths to the training and test data files (`Training_Data.csv` and `Test_Data.csv`) in the notebook if necessary.
8. Execute the code cells in the notebook to perform data analysis, preprocessing, model training, and evaluation.

## Results
The project aims to build a machine learning model to predict user knowledge based on the provided dataset. The model's performance and evaluation metrics will be discussed in detail within the Jupyter Notebook and report pdf.

## Acknowledgments
The dataset used in this project, "User Knowledge Modeling Data Set," was sourced from UCI. More details can be found from the following UCI webpage about this dataset: https://archive.ics.uci.edu/ml/datasets/User+Knowledge+Modeling



